/* O loop deve ser no máximo até 10 Termos, nada mais do que isso, fazer apenas a raíz e o valor inicial.*/

function PA(){
    var valor = parseInt(document.getElementById("inicial").value);
    var razao = parseInt(document.getElementById("razao").value);
    var termo = parseInt(10)

    var pg = "";

    for(var count=1; count<= termo; count++){
        pg += "Termo "+count+" = "+valor+"<br />";
        valor *= razao;

    }
    
    pg = document.getElementById('span').innerHTML = pg;
}